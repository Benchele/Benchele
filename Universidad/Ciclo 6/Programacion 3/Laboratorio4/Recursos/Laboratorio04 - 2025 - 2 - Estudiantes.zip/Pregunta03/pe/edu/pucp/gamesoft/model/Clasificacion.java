package pe.edu.pucp.gamesoft.model;
public enum Clasificacion{
	Everyone, Teen, Mature, Adults
}
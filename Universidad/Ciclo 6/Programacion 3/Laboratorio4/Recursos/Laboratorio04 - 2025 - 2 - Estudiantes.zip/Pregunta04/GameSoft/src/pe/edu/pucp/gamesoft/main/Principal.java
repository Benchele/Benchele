package pe.edu.pucp.gamesoft.main;

public class Principal {
    
    public static void main(String[] args){
        
    }

}